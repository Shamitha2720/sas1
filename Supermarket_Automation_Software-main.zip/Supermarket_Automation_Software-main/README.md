# Supermarket Automation Software(SAS)
Built using Flask ,SQLalchemy and python.



